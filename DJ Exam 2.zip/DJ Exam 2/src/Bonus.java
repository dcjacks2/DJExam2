public interface Bonus {
    //Complete the definition
    double computeBonus();
}
