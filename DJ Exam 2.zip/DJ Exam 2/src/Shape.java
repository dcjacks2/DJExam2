abstract class Shape {

    abstract double Area();
}
