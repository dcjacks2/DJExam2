public class Student {
    private String name;
    private double marks;
    public void setName(String n){
        name = n;
    }
    //define a setter method to asign value to marks
    public void setMarks(double m ){
        marks = m;
    }
    public String getName(){
        return name;
    }
    //define a getter method to read the value of marks
    public double getMarks(){
        return marks;
    }

}
