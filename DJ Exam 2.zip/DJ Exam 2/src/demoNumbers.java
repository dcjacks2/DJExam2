public class demoNumbers {
    public static void main(String[] args){
        //create an object for the Numbers class
        Numbers n1 = new Numbers(1,2);
        // call all the display methods
        n1.display();
        n1.display("hello",5);
        n1.display(4,3);

    }

}
