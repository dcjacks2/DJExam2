public class DemoEmployee {
    public static void main(String[] args){
        Employee e = new Employee("Bob", 72, 14.5);
        e.display();
    }


}
