public interface Arithmetic {
    public void computeArithmetic();
}
